package es.ciudadescolar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdUd07TrabajoSpringComponentesMateoAyarraMarioGarciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
